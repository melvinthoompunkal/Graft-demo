from datetime import datetime
from typing import TYPE_CHECKING, Any, Literal
from warnings import warn
from openbb_core.provider.abstract.fetcher import Fetcher
from openbb_core.provider.standard_models.equity_historical import (
from openbb_core.provider.utils.descriptions import QUERY_DESCRIPTIONS
from openbb_core.provider.utils.errors import EmptyDataError
from openbb_yfinance.utils.references import INTERVALS_DICT, PERIODS
from pydantic import Field, PrivateAttr
    from pandas import DataFrame
        from dateutil.relativedelta import relativedelta
        from openbb_yfinance.utils.helpers import yf_download

    adjustment: Literal["splits_only", "splits_and_dividends"] = Field(
        default="splits_only",
        description="The adjustment factor to apply. Default is splits only.",
    )

    _ignore_tz: bool = PrivateAttr(default=True)
    _progress: bool = PrivateAttr(default=False)
    _keepna: bool = PrivateAttr(default=False)
    _period: PERIODS = PrivateAttr(default="max")
    _rounding: bool = PrivateAttr(default=False)
    _repair: bool = PrivateAttr(default=False)
    _group_by: Literal["ticker", "column"] = PrivateAttr(default="ticker")


class YFinanceEquityHistoricalData(EquityHistoricalData):
    """Yahoo Finance Equity Historical Price Data."""

    __alias_dict__ = {
        "split_ratio": "stock_splits",
        "dividend": "dividends",
    }

    split_ratio: float | None = Field(
        default=None,
        description="Ratio of the equity split, if a split occurred.",
    )
    dividend: float | None = Field(
        default=None,
        description="Dividend amount (split-adjusted), if a dividend was paid.",
    )


class YFinanceEquityHistoricalFetcher(
    Fetcher[
        YFinanceEquityHistoricalQueryParams,
        list[YFinanceEquityHistoricalData],
    ]
):
    """Transform the query, extract and transform the data from the Yahoo Finance endpoints."""

    @staticmethod
    def transform_query(params: dict[str, Any]) -> YFinanceEquityHistoricalQueryParams:
        """Transform the query."""
        # pylint: disable=import-outside-toplevel
        from dateutil.relativedelta import relativedelta

        transformed_params = params
        now = datetime.now().date()

        if params.get("start_date") is None:
            transformed_params["start_date"] = now - relativedelta(years=1)

        if params.get("end_date") is None:
            transformed_params["end_date"] = now

        return YFinanceEquityHistoricalQueryParams(**params)

    @staticmethod
    def extract_data(
        query: YFinanceEquityHistoricalQueryParams,
        credentials: dict[str, str] | None,
        **kwargs: Any,
    ) -> "DataFrame":
        """Return the raw data from the Yahoo Finance endpoint."""
        # pylint: disable=import-outside-toplevel
        from openbb_yfinance.utils.helpers import yf_download

        adjusted = query.adjustment == "splits_and_dividends"
        kwargs = {"auto_adjust": True, "back_adjust": True} if adjusted is True else {}
        # pylint: disable=protected-access
        data = yf_download(
            symbol=query.symbol,
            start_date=query.start_date,
            end_date=query.end_date,
            interval=INTERVALS_DICT[query.interval],  # type: ignore
    _period: PERIODS = PrivateAttr(default="max")
    _rounding: bool = PrivateAttr(default=False)
    _repair: bool = PrivateAttr(default=False)
    _group_by: Literal["ticker", "column"] = PrivateAttr(default="ticker")


class YFinanceEquityHistoricalData(EquityHistoricalData):
    """Yahoo Finance Equity Historical Price Data."""

    __alias_dict__ = {
        "split_ratio": "stock_splits",
        "dividend": "dividends",
    }

    split_ratio: float | None = Field(
        default=None,
        description="Ratio of the equity split, if a split occurred.",
    dividend: float | None = Field(
        default=None,
        description="Dividend amount (split-adjusted), if a dividend was paid.",
    )


class YFinanceEquityHistoricalFetcher(
    Fetcher[
        YFinanceEquityHistoricalQueryParams,
        list[YFinanceEquityHistoricalData],
    ]
):
    """Transform the query, extract and transform the data from the Yahoo Finance endpoints."""

    @staticmethod
    def transform_query(params: dict[str, Any]) -> YFinanceEquityHistoricalQueryParams:
        """Transform the query."""
        # pylint: disable=import-outside-toplevel
        from dateutil.relativedelta import relativedelta

        transformed_params = params
        now = datetime.now().date()

        if params.get("start_date") is None:
            transformed_params["start_date"] = now - relativedelta(years=1)

        if params.get("end_date") is None:

        return YFinanceEquityHistoricalQueryParams(**params)

    @staticmethod
    def extract_data(
        query: YFinanceEquityHistoricalQueryParams,
        credentials: dict[str, str] | None,
        **kwargs: Any,
    ) -> "DataFrame":
        """Return the raw data from the Yahoo Finance endpoint."""
        # pylint: disable=import-outside-toplevel
        from openbb_yfinance.utils.helpers import yf_download

        adjusted = query.adjustment == "splits_and_dividends"
        kwargs = {"auto_adjust": True, "back_adjust": True} if adjusted is True else {}
        # pylint: disable=protected-access
        data = yf_download(
            symbol=query.symbol,
            start_date=query.start_date,
            end_date=query.end_date,
            interval=INTERVALS_DICT[query.interval],  # type: ignore
