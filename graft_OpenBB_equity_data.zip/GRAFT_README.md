# Graft Feature Bundle

## Feature

This bundle contains the `equity_data` feature extracted from `OpenBB`.

## What It Does

The Equity Data Access feature works through a multi-layered architecture. When a user calls obb.equity.price.historical(), the request hits the historical() function in the price router, which serves as the main entry point. The system first validates and standardizes the query parameters (symbol, dates, interval) using EquityHistoricalQueryParams with built-in validators that convert symbols to uppercase and parse dates. The router then selects an appropriate data provider (Yahoo Finance, Alpha Vantage, FMP, etc.) based on user preference or availability. Each provider implements a Fetcher class that follows a three-step pattern: 1) transform_query() adapts the standardized parameters to the provider's API requirements and applies defaults (like 1-year lookback), 2) extract_data() makes HTTP requests to fetch raw OHLCV data from the provider's endpoints, and 3) transform_data() converts the raw response into the standardized EquityHistoricalData format. The standardized data model ensures consistent output across all providers, containing fields like open, high, low, close, volume, and optional metrics. This architecture allows users to seamlessly switch between data providers while maintaining a consistent interface and data format.

## How The Files Connect

The Equity Data Access feature works through a multi-layered architecture. When a user calls obb.equity.price.historical(), the request hits the historical() function in the price router, which serves as the main entry point. The system first validates and standardizes the query parameters (symbol, dates, interval) using EquityHistoricalQueryParams with built-in validators that convert symbols to uppercase and parse dates. The router then selects an appropriate data provider (Yahoo Finance, Alpha Vantage, FMP, etc.) based on user preference or availability. Each provider implements a Fetcher class that follows a three-step pattern: 1) transform_query() adapts the standardized parameters to the provider's API requirements and applies defaults (like 1-year lookback), 2) extract_data() makes HTTP requests to fetch raw OHLCV data from the provider's endpoints, and 3) transform_data() converts the raw response into the standardized EquityHistoricalData format. The standardized data model ensures consistent output across all providers, containing fields like open, high, low, close, volume, and optional metrics. This architecture allows users to seamlessly switch between data providers while maintaining a consistent interface and data format.

## Environment Variables

- `alpha_vantage_api_key`
- `intrinio_api_key`
- `tiingo_token`

## Install Dependencies

Run `Install dependencies using the included manifest if needed.`.

## Source Credit

Extracted from https://github.com/OpenBB-finance/OpenBB.
