# Graft Feature Bundle

## Feature

This bundle contains the `multi_agent_simulation` feature extracted from `MiroFish`.

## What It Does

The Multi-Agent Digital World Simulation creates high-fidelity parallel worlds with thousands of intelligent agents. The process begins when prepare_simulation is called, which orchestrates three key phases: (1) Entity Reading - The system reads entities from a Zep knowledge graph using filter_defined_entities to identify potential agents for the simulation. (2) Profile Generation - generate_profiles_from_entities creates unique personalities for each agent using LLM-powered generation via _generate_profile_with_llm, producing detailed traits, interests, and behavioral patterns. (3) Configuration Generation - generate_config uses LLM analysis to create simulation parameters including agent activity levels, social dynamics, and temporal patterns. Once prepared, start_simulation launches parallel execution across Twitter and Reddit platforms. The simulation_runner spawns subprocesses that execute platform-specific simulations (run_twitter_simulation and run_reddit_simulation) where thousands of agents with independent personalities take actions based on their traits and long-term memories. The _monitor_simulation function tracks real-time agent actions across both platforms, while zep_graph_memory_updater maintains persistent memory of all agent interactions. Throughout the simulation, agents can be interviewed via interview_agent to query their internal state and reasoning, demonstrating their evolved behavioral patterns and social memories. The frontend provides real-time visualization of agent actions and world evolution through a dual-platform timeline interface.

## How The Files Connect

The Multi-Agent Digital World Simulation creates high-fidelity parallel worlds with thousands of intelligent agents. The process begins when prepare_simulation is called, which orchestrates three key phases: (1) Entity Reading - The system reads entities from a Zep knowledge graph using filter_defined_entities to identify potential agents for the simulation. (2) Profile Generation - generate_profiles_from_entities creates unique personalities for each agent using LLM-powered generation via _generate_profile_with_llm, producing detailed traits, interests, and behavioral patterns. (3) Configuration Generation - generate_config uses LLM analysis to create simulation parameters including agent activity levels, social dynamics, and temporal patterns. Once prepared, start_simulation launches parallel execution across Twitter and Reddit platforms. The simulation_runner spawns subprocesses that execute platform-specific simulations (run_twitter_simulation and run_reddit_simulation) where thousands of agents with independent personalities take actions based on their traits and long-term memories. The _monitor_simulation function tracks real-time agent actions across both platforms, while zep_graph_memory_updater maintains persistent memory of all agent interactions. Throughout the simulation, agents can be interviewed via interview_agent to query their internal state and reasoning, demonstrating their evolved behavioral patterns and social memories. The frontend provides real-time visualization of agent actions and world evolution through a dual-platform timeline interface.

## Environment Variables

- `ANTHROPIC_API_KEY`
- `LLM_API_KEY`
- `LLM_BASE_URL`
- `LLM_MODEL_NAME`
- `OPENAI_API_BASE_URL`
- `OPENAI_API_KEY`
- `SIMULATION_DATA_DIR`
- `ZEP_API_KEY`

## Install Dependencies

Run `npm install`.

## Source Credit

Extracted from https://github.com/666ghj/MiroFish.
