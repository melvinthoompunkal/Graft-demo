# Graft Feature Bundle

## Feature

This bundle contains the `multi_channel_messaging` feature extracted from `openclaw`.

## What It Does

The Multi-Channel Messaging feature works through a layered architecture that connects to 20+ messaging platforms. Here's the step-by-step flow: 1) The system starts with `isMessagingTool` in the core messaging module, which identifies whether an incoming tool request is for messaging by checking against a predefined set of core messaging tools or channel-specific plugin actions. 2) If it's a messaging tool, `isMessagingToolSendAction` determines if it's specifically a send operation by examining the tool name and action parameters. 3) The plugin discovery system kicks in via `resolveCurrentChannelMessageToolDiscoveryAdapter`, which dynamically loads the appropriate messaging adapter for the target platform (Discord, WhatsApp, Telegram, QQ Bot, etc.). 4) `listChannelMessageActions` enumerates all available messaging capabilities across all configured channel plugins, enabling the system to understand what each platform supports. 5) For Discord channels, `handleDiscordMessagingAction` routes the request to platform-specific handlers, then `handleDiscordMessageSendAction` processes Discord-specific features like stickers, polls, threads, and voice messages. 6) For QQ Bot channels, the system uses `sendText` for text messages and `sendMedia` for rich media content, with `handleStructuredPayload` routing different media types appropriately. 7) WhatsApp integration handles authentication and session management through `loginWeb` with retry logic for various error conditions. The architecture maintains a common messaging interface while delegating to provider-specific implementations, allowing seamless multi-platform messaging with platform-specific feature support.

## How The Files Connect

The Multi-Channel Messaging feature works through a layered architecture that connects to 20+ messaging platforms. Here's the step-by-step flow: 1) The system starts with `isMessagingTool` in the core messaging module, which identifies whether an incoming tool request is for messaging by checking against a predefined set of core messaging tools or channel-specific plugin actions. 2) If it's a messaging tool, `isMessagingToolSendAction` determines if it's specifically a send operation by examining the tool name and action parameters. 3) The plugin discovery system kicks in via `resolveCurrentChannelMessageToolDiscoveryAdapter`, which dynamically loads the appropriate messaging adapter for the target platform (Discord, WhatsApp, Telegram, QQ Bot, etc.). 4) `listChannelMessageActions` enumerates all available messaging capabilities across all configured channel plugins, enabling the system to understand what each platform supports. 5) For Discord channels, `handleDiscordMessagingAction` routes the request to platform-specific handlers, then `handleDiscordMessageSendAction` processes Discord-specific features like stickers, polls, threads, and voice messages. 6) For QQ Bot channels, the system uses `sendText` for text messages and `sendMedia` for rich media content, with `handleStructuredPayload` routing different media types appropriately. 7) WhatsApp integration handles authentication and session management through `loginWeb` with retry logic for various error conditions. The architecture maintains a common messaging interface while delegating to provider-specific implementations, allowing seamless multi-platform messaging with platform-specific feature support.

## Environment Variables

- `TMPDIR`

## Install Dependencies

Run `npm install`.

## Source Credit

Extracted from https://github.com/openclaw/openclaw.
