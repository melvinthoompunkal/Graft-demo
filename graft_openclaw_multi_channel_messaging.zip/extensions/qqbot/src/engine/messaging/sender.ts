import os from "node:os";
import { ApiClient } from "../api/api-client.js";
import { ChunkedMediaApi as ChunkedMediaApiClass } from "../api/media-chunked.js";
import { MediaApi as MediaApiClass } from "../api/media.js";
import type { Credentials } from "../api/messages.js";
import { MessageApi as MessageApiClass } from "../api/messages.js";
import { getNextMsgSeq } from "../api/routes.js";
import { TokenManager } from "../api/token.js";
import {
import { LARGE_FILE_THRESHOLD } from "../utils/file-utils.js";
import { formatErrorMessage } from "../utils/format.js";
import { debugLog, debugError, debugWarn } from "../utils/log.js";
import { sanitizeFileName } from "../utils/string-normalize.js";
import { computeFileHash, getCachedFileInfo, setCachedFileInfo } from "../utils/upload-cache.js";
import { normalizeSource, type MediaSource, type RawMediaSource } from "./media-source.js";

    log?: {
      info: (msg: string) => void;
      error: (msg: string) => void;
      debug?: (msg: string) => void;
    };
  },
): void {
  resolveAccount(appId).tokenMgr.startBackgroundRefresh(appId, clientSecret, options);
}

export function stopBackgroundTokenRefresh(appId?: string): void {
  if (appId) {
    resolveAccount(appId).tokenMgr.stopBackgroundRefresh(appId);
  } else {
    for (const ctx of _accountRegistry.values()) {
      ctx.tokenMgr.stopBackgroundRefresh();
    }
  }
}

export function isBackgroundTokenRefreshRunning(appId?: string): boolean {
  if (appId) {
    return resolveAccount(appId).tokenMgr.isBackgroundRefreshRunning(appId);
  }
  for (const ctx of _accountRegistry.values()) {
  const api = resolveAccount(creds.appId).messageApi;
  const c: Credentials = { appId: creds.appId, clientSecret: creds.clientSecret };

  if (target.type === "c2c" || target.type === "group") {
    const scope: ChatScope = target.type;
    if (opts?.msgId) {
      return api.sendMessage(scope, target.id, content, c, {
        msgId: opts.msgId,
        messageReference: opts.messageReference,
