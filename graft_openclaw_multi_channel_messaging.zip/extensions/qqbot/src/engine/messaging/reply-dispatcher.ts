import crypto from "node:crypto";
import path from "node:path";
import { MediaFileType, type GatewayAccount } from "../types.js";
import { formatFileSize, getImageMimeType, getMaxUploadSize } from "../utils/file-utils.js";
import { formatErrorMessage } from "../utils/format.js";
import {
import { normalizePath, resolveQQBotPayloadLocalFilePath } from "../utils/platform.js";
import { normalizeLowercaseStringOrEmpty } from "../utils/string-normalize.js";
import { sanitizeFileName } from "../utils/string-normalize.js";
import { openLocalFile } from "./media-source.js";
import {

// ---- Structured payload handling ----

/**
 * Handle a structured payload prefixed with `QQBOT_PAYLOAD:`.
 * Returns true when the reply was handled here, otherwise false.
 */
export async function handleStructuredPayload(
  ctx: ReplyContext,
  replyText: string,
  recordActivity: () => void,
  deps?: ReplyDispatcherDeps,
): Promise<boolean> {
  const { account: _account, log } = ctx;
  const payloadResult = parseQQBotPayload(replyText);

  if (!payloadResult.isPayload) {
    return false;
  }

  if (payloadResult.error) {
    log?.error(`Payload parse error: ${payloadResult.error}`);
    return true;
  }

  if (!payloadResult.payload) {
    return true;
  }

  const parsedPayload = payloadResult.payload;
  const unknownPayload = payloadResult.payload as unknown;
  log?.info(`Detected structured payload, type: ${parsedPayload.type}`);

  if (isCronReminderPayload(parsedPayload)) {
    log?.debug?.(`Processing cron_reminder payload`);
    const cronMessage = encodePayloadForCron(parsedPayload);
    const confirmText = `⏰ Reminder scheduled. It will be sent at the configured time: "${parsedPayload.content}"`;
    try {
      await sendTextToTarget(ctx, confirmText);
      log?.debug?.(`Cron reminder confirmation sent, cronMessage: ${cronMessage}`);
    } catch (err) {
      log?.error(`Failed to send cron confirmation: ${formatErrorMessage(err)}`);
    }
    recordActivity();
    return true;
  }

  if (isMediaPayload(parsedPayload)) {
    log?.debug?.(`Processing media payload, mediaType: ${parsedPayload.mediaType}`);

    if (parsedPayload.mediaType === "image") {
      await handleImagePayload(ctx, parsedPayload);
    } else if (parsedPayload.mediaType === "audio") {
      await handleAudioPayload(ctx, parsedPayload, deps);
    } else if (parsedPayload.mediaType === "video") {
      await handleVideoPayload(ctx, parsedPayload);
    } else if (parsedPayload.mediaType === "file") {
      await handleFilePayload(ctx, parsedPayload);
    } else {
      log?.error(`Unknown media type: ${JSON.stringify(parsedPayload.mediaType)}`);
