import type { AgentToolResult } from "@mariozechner/pi-agent-core";
import type { ActionGate, DiscordActionConfig, OpenClawConfig } from "../runtime-api.js";
import { handleDiscordMessageManagementAction } from "./runtime.messaging.messages.js";
import { handleDiscordReactionMessagingAction } from "./runtime.messaging.reactions.js";
import { handleDiscordMessageSendAction } from "./runtime.messaging.send.js";
import {

export async function handleDiscordMessagingAction(
  action: string,
  params: Record<string, unknown>,
  isActionEnabled: ActionGate<DiscordActionConfig>,
  cfg: OpenClawConfig,
  options?: DiscordMessagingActionOptions,
): Promise<AgentToolResult<unknown>> {
  if (!cfg) {
    throw new Error("Discord messaging actions require a resolved runtime config.");
  }
  const ctx = createDiscordMessagingActionContext({
    action,
    input: params,
    isActionEnabled,
    cfg,
    options,
  });
  return (
    (await handleDiscordReactionMessagingAction(ctx)) ??
